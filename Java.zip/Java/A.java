final class A {
    final int x = 10;

    final void show() {
        System.out.println(x);
    }
}


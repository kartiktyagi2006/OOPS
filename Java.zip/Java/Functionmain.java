public class Functionmain {
    int x;  
    void display() {   
        System.out.println(x);
    }

    public static void main(String[] args) {
        Functionmain obj = new  Functionmain();   
        obj.x = 10;            
        obj.display();          
    }
}


public class car {

    public static void main(String[] args) {

        int car_modelnum;
        int car_price;
        car_modelnum = 101;
        car_price = 800000;
        System.out.println("Car Model Number: " + car_modelnum);
        System.out.println("Car Price: " + car_price);
    }
}

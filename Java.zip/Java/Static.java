class Static {
    static int number = 10;
    public static void main(String[] args) {
        System.out.println(Static.number);
    }
}
